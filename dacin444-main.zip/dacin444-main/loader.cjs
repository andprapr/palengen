// loader.cjs
(async () => {
    await import('./index.js');
})();